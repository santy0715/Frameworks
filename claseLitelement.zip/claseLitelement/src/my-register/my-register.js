import { LitElement, html } from 'lit-element';
import styleRegister from "./my-registerStyle";

export class MyElement extends LitElement {
    static get styles() {
        return [styleRegister];
    }
    static get properties() {
        return {
            firstName: { type: String },
            lastName: { type: String },
            email: { type: String },
            password: { type: String }
        };
    }
    constructor() {
        super();
        this.firstname = '';
        this.lastname = '';
        this.email = '';
        this.password = '';
    }

    handleFirstnameInput(event) {
        this.firstname = event.target.value;
    }

    handleLastnameInput(event) {
        this.lastname = event.target.value;
    }

    handleEmailInput(event) {
        this.email = event.target.value;
    }

    handlePasswordInput(event) {
        this.password = event.target.value;
    }

    handleFormSubmit(event) {
        event.preventDefault(); // Evita que el formulario se envíe
        console.log('Datos registrados:');
        console.log('Firstname:', this.firstname);
        console.log('Lastname:', this.lastname);
        console.log('Email:', this.email);
        console.log('Password:', this.password);
    }

    render() {
        return html`
            <form class="form" @submit="${this.handleFormSubmit}">
                <h1 class="form_heading">REGISTRAR</h1>
                <p class="message">Signup now and get full access to our app.</p>
                <div class="flex">
                    <label>
                        <input required placeholder="" type="text" class="input" @input="${this.handleFirstnameInput}">
                        <span>Firstname</span>
                    </label>

                    <label>
                        <input required placeholder="" type="text" class="input" @input="${this.handleLastnameInput}">
                        <span>Lastname</span>
                    </label>
                </div>

                <label>
                    <input required placeholder="" type="email" class="input" @input="${this.handleEmailInput}">
                    <span>Email</span>
                </label>

                <label>
                    <input required placeholder="" type="password" class="input" @input="${this.handlePasswordInput}">
                    <span>Password</span>
                </label>
                <button type="submit" class="submit">Submit</button>
            </form>
        `;
    }
}
const loginButton = document.getElementById('loginButton');
const registerButton = document.getElementById('registerButton');
const loginPage = document.querySelector('my-login');
const registerPage = document.querySelector('my-register');

registerPage.style.display = 'none';

loginButton.addEventListener('click', () => {
  loginPage.style.display = 'block';
  registerPage.style.display = 'none';
});

registerButton.addEventListener('click', () => {
  loginPage.style.display = 'none';
  registerPage.style.display = 'block';
});

customElements.define('my-register', MyElement);
