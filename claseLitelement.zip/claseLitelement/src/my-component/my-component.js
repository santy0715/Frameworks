import { LitElement, html } from 'lit-element';
import style from "./my-componentStyle";
export class MyElement extends LitElement {
     
constructor(){
    super()
    this.saludo="Saludo 2"
}

static get properties(){
    return{
        saludo: { type: String}
    };
}
cambio(){
    this.saludo="El primer componente"
}
static get styles(){
    return[style]
}
render() {
  return html`
    <p class"primerElemento">Soy ${this.saludo}</p>
    <button @click=${(e)=>this.cambio()}>Cambias Saludo</button>
  `;
  }
}

customElements.define('my-element', MyElement);