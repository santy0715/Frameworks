import { css } from "lit-element";

export default css `
.primerElemento{
    font-size: 21px;
}
` 


