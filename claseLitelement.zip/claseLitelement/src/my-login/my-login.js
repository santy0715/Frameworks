import { LitElement, html } from 'lit-element';
import styleLogin from "./my-loginStyle";

export class MyElement extends LitElement {
    static get styles() {
        return [styleLogin];
    }

    // Agrega un constructor para inicializar propiedades y estados si es necesario.
    constructor() {
        super();
        this.username = '';
        this.password = '';
    }

    // Manejador de evento para el botón de "Login".
    handleLoginClick() {
        // Aquí puedes agregar la lógica de inicio de sesión, por ejemplo, hacer una solicitud a un servidor o validar los campos de entrada.
        if (this.username && this.password) {
            // Lógica de inicio de sesión exitosa
            alert('Inicio de sesión exitoso');
        } else {
            // Lógica de inicio de sesión fallido
            alert('Error: Nombre de usuario y contraseña son obligatorios');
        }
    }

    render() {
        return html`
            <form class="form card">
                <div class="card_header">
                    <h1 class="form_heading">LOGIN</h1>
                </div>
                <div class="field">
                    <label for="username">Username</label>
                    <input class="input" name="username" type="text" placeholder="Username" id="username" @input=${(e) => this.username = e.target.value}>
                </div>
                <div class="field">
                    <label for="password">Password</label>
                    <input class="input" name="user_password" type="password" placeholder="Password" id="password" @input=${(e) => this.password = e.target.value}>
                </div>
                <div class="field">
                    <button class="button" @click=${this.handleLoginClick}>Login</button>
                </div>
            </form>
        `;
    }
}
const loginButton = document.getElementById('loginButton');
const registerButton = document.getElementById('registerButton');
const loginPage = document.querySelector('my-login');
const registerPage = document.querySelector('my-register');

registerPage.style.display = 'none';

loginButton.addEventListener('click', () => {
  loginPage.style.display = 'block';
  registerPage.style.display = 'none';
});

registerButton.addEventListener('click', () => {
  loginPage.style.display = 'none';
  registerPage.style.display = 'block';
});

customElements.define('my-login', MyElement);
